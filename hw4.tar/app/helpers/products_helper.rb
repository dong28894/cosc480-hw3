module ProductsHelper
    def empty_product
        Product.new
    end
end
